const { Sequelize } = require("sequelize");
require("dotenv").config();

const env = process.env.NODE_ENV || "development";

// Vérification des variables d'environnement
if (!process.env.DB_NAME || !process.env.DB_USER || !process.env.DB_HOST) {
  console.error("Erreur : Certaines variables d'environnement sont manquantes !");
  process.exit(1); // Stop l'exécution si des variables sont absentes
}

console.log("🔹 Chargement des variables d'environnement...");
console.log("DB_NAME:", process.env.DB_NAME);
console.log("DB_USER:", process.env.DB_USER);
console.log("DB_HOST:", process.env.DB_HOST);


const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASS || "", // Supporte les mots de passe vides
  {
    host: process.env.DB_HOST,
    dialect: "mysql",
    logging: false, // Désactive les logs SQL pour plus de clarté
    define: {
      timestamps: true, // Ajoute automatiquement `createdAt` et `updatedAt`
      freezeTableName: true, // Évite la transformation des noms de tables en pluriel
    },
  }
);

// Vérification de la connexion à la base de données
sequelize.authenticate()
  .then(() => {
    console.log(`Connexion à MySQL réussie. Base utilisée : ${process.env.DB_NAME}`);
  })
  .catch(err => {
    console.error("Erreur de connexion MySQL :", err);
    process.exit(1);
  });

module.exports = sequelize;
