const Order = require("../models/Order");
const User = require("../models/User");
const Product = require("../models/Product");

/**
 * @description Récupère toutes les commandes avec les utilisateurs et les produits associés
 */
exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.findAll({
      include: [
        { model: User, attributes: ["id", "username"] },
        { model: Product, attributes: ["id", "productName", "description", "price"] }
      ]
    });

    if (!orders || !Array.isArray(orders) || orders.length === 0) {
      return res.status(404).json({ error: "Aucune commande trouvée." });
    }

    res.status(200).json(orders);
  } catch (error) {
    console.error("Erreur getAllOrders:", error);
    res.status(500).json({ error: "Erreur serveur lors de la récupération des commandes." });
  }
};

/**
 * @description Crée une commande pour un utilisateur
 */
exports.createOrder = async (req, res) => {
  try {
    const { productId, quantity } = req.body;

    if (!productId || !quantity || isNaN(quantity) || quantity <= 0) {
      return res.status(400).json({ error: "Veuillez fournir un produit valide et une quantité supérieure à zéro." });
    }

    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: "Authentification requise." });
    }

    // Vérifie si le produit existe
    const product = await Product.findByPk(productId);
    if (!product) {
      return res.status(404).json({ error: "Produit non trouvé." });
    }

    // Vérifie si l'utilisateur existe
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: "Utilisateur non trouvé." });
    }

    // Création de la commande
    const order = await Order.create({ userId, productId, quantity });

    res.status(201).json({ message: "Commande créée avec succès", order });
  } catch (error) {
    console.error("Erreur createOrder:", error);
    res.status(500).json({ error: "Erreur serveur lors de la création de la commande." });
  }
};
