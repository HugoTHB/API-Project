const Product = require("../models/Product");

exports.createProduct = async (req, res) => {
    try {
        const { productName, description, price } = req.body;

        if (!productName || !description || !price) {
            return res.status(400).json({ error: "Tous les champs sont requis" });
        }

        const product = await Product.create({ productName, description, price });
        res.status(201).json({ message: "Produit créé avec succès", product });
    } catch (error) {
        console.error("Erreur createProduct:", error);
        res.status(500).json({ error: "Erreur interne du serveur" });
    }
};
