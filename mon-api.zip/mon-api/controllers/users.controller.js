const User = require("../models/User");
const bcrypt = require("bcryptjs");

/**
 * @description Crée un nouvel utilisateur
 */
exports.createUser = async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: "Veuillez fournir un nom d'utilisateur et un mot de passe." });
        }

        // Vérifier si l'utilisateur existe déjà
        const existingUser = await User.findOne({ where: { username } });
        if (existingUser) {
            return res.status(400).json({ error: "Ce nom d'utilisateur est déjà pris." });
        }

        // Hash du mot de passe avant sauvegarde
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await User.create({ username, password: hashedPassword });

        console.log(`Utilisateur créé : ${newUser.username}`);
        res.status(201).json({ message: "Utilisateur créé avec succès", user: { id: newUser.id, username: newUser.username } });
    } catch (error) {
        console.error("Erreur lors de la création de l'utilisateur :", error);
        res.status(500).json({ error: "Erreur serveur lors de la création de l'utilisateur." });
    }
};

/**
 * @description Récupère tous les utilisateurs
 */
exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.findAll({ attributes: ["id", "username"] });

        if (users.length === 0) {
            return res.status(404).json({ message: "Aucun utilisateur trouvé." });
        }

        console.log("Liste des utilisateurs récupérée avec succès.");
        res.status(200).json(users);
    } catch (error) {
        console.error("Erreur lors de la récupération des utilisateurs :", error);
        res.status(500).json({ error: "Erreur serveur lors de la récupération des utilisateurs." });
    }
};

/**
 * @description Supprime un utilisateur par ID
 */
exports.deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;

        // Vérifier si l'ID est valide
        if (!userId || isNaN(userId)) {
            return res.status(400).json({ error: "ID utilisateur invalide." });
        }

        // Vérifier si l'utilisateur existe
        const user = await User.findByPk(userId);
        if (!user) {
            return res.status(404).json({ error: "Utilisateur non trouvé." });
        }

        // Supprimer l'utilisateur
        await user.destroy();
        console.log(`Utilisateur supprimé : ${user.username}`);
        res.status(200).json({ message: "Utilisateur supprimé avec succès." });

    } catch (error) {
        console.error("Erreur lors de la suppression de l'utilisateur :", error);
        res.status(500).json({ error: "Erreur serveur lors de la suppression de l'utilisateur." });
    }
};
