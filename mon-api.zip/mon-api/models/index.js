const { Sequelize } = require("sequelize");
const sequelize = require("../config/database");

const User = require("./User");
const Product = require("./Product");
const Order = require("./Order");

const db = { sequelize, Sequelize, User, Product, Order };

User.hasMany(Order, { foreignKey: "userId", onDelete: "CASCADE" });
Order.belongsTo(User, { foreignKey: "userId" });

Product.hasMany(Order, { foreignKey: "productId", onDelete: "CASCADE" });
Order.belongsTo(Product, { foreignKey: "productId" });

module.exports = db;
