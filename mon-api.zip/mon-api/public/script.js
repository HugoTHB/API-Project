document.addEventListener("DOMContentLoaded", function () {
    const loginSection = document.getElementById("loginSection");
    const userSection = document.getElementById("userSection");
    const userInfo = document.getElementById("userInfo");
    const productList = document.getElementById("productList");
    const productDropdown = document.getElementById("productDropdown");

    const token = localStorage.getItem("token");
    if (token) {
        afficherUtilisateurs();
        afficherNomUtilisateur();
        chargerProduitsDisponibles();
        afficherProduits();
        loginSection.style.display = "none";
        userSection.style.display = "block";
    }

    window.connecterUtilisateur = function () {
        const username = document.getElementById("loginUsername").value.trim();
        const password = document.getElementById("loginPassword").value.trim();

        console.log("Tentative de connexion avec :", username, password);

        if (!username || !password) {
            alert("Veuillez remplir tous les champs !");
            return;
        }

        fetch("http://localhost:3000/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Échec de connexion : ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.token) {
                localStorage.setItem("token", data.token);
                localStorage.setItem("username", username);
                alert("Connexion réussie !");
                afficherUtilisateurs();
                afficherNomUtilisateur();
                chargerProduitsDisponibles();
                afficherProduits();
                loginSection.style.display = "none";
                userSection.style.display = "block";
            } else {
                alert("Erreur : Identifiants incorrects.");
            }
        })
        .catch(error => {
            console.error("Erreur :", error);
            alert("Connexion échouée : " + error.message);
        });
    };

    function afficherNomUtilisateur() {
        const username = localStorage.getItem("username");
        if (username) {
            userInfo.textContent = "Connecté en tant que : " + username;
        }
    }

    function afficherUtilisateurs() {
        fetch("http://localhost:3000/users", {
            headers: { "Authorization": "Bearer " + localStorage.getItem("token") }
        })
        .then(response => response.json())
        .then(users => {
            const userList = document.getElementById("userList");
            userList.innerHTML = "";
            users.forEach(user => {
                const p = document.createElement("p");
                p.textContent = user.username;
                userList.appendChild(p);
            });
        })
        .catch(error => console.error("Erreur :", error));
    }

    function chargerProduitsDisponibles() {
        fetch("http://localhost:3000/products", {
            headers: { "Authorization": "Bearer " + localStorage.getItem("token") }
        })
        .then(response => response.json())
        .then(products => {
            productDropdown.innerHTML = "";
            products.forEach(product => {
                const option = document.createElement("option");
                option.value = product.id;
                option.textContent = `${product.id} - ${product.productName}`;
                productDropdown.appendChild(option);
            });
        })
        .catch(error => console.error("Erreur lors du chargement des produits :", error));
    }

    window.ajouterUtilisateur = function () {
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();
    
        if (!username || !password) {
            alert("Veuillez remplir tous les champs !");
            return;
        }
    
        fetch("http://localhost:3000/users", {  
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert("Erreur : " + data.error);
            } else {
                alert("Utilisateur ajouté avec succès !");
                afficherUtilisateurs(); 
            }
        })
        .catch(error => console.error("Erreur lors de l'ajout de l'utilisateur :", error));
    };

    window.ajouterProduit = function () {
        const productId = productDropdown.value;
        const quantity = document.getElementById("quantity").value.trim();

        console.log("Ajout produit ID:", productId, "Quantité:", quantity);

        if (!productId || !quantity || isNaN(quantity) || quantity <= 0) {
            alert("Veuillez entrer un produit valide et une quantité supérieure à zéro !");
            return;
        }

        fetch("http://localhost:3000/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify({ productId: parseInt(productId), quantity: parseInt(quantity) })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert("Erreur : " + data.error);
            } else {
                alert("Produit ajouté avec succès !");
                afficherProduits();
            }
        })
        .catch(error => console.error("Erreur lors de l'ajout du produit :", error));
    };

    function afficherProduits() {
        fetch("http://localhost:3000/orders", {
            headers: { "Authorization": "Bearer " + localStorage.getItem("token") }
        })
        .then(response => response.json())
        .then(products => {
            productList.innerHTML = "";
            if (Array.isArray(products)) {
                products.forEach(product => {
                    const p = document.createElement("p");
                    p.textContent = `${product.productName} - ${product.quantity}`;
                    productList.appendChild(p);
                });
            } else {
                console.error("Erreur : La réponse n'est pas un tableau", products);
            }
        })
        .catch(error => console.error("Erreur :", error));
    }

    window.logout = function () {
        localStorage.removeItem("token");
        localStorage.removeItem("username");
        alert("Déconnexion réussie !");
        userInfo.textContent = "";
        loginSection.style.display = "block";
        userSection.style.display = "none";
    };
});
