const express = require("express");
const { createOrder, getAllOrders } = require("../controllers/orders.controller");
const authMiddleware = require("../middlewares/authMiddleware");

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Orders
 *   description: Gestion des commandes et produits
 */

/**
 * @swagger
 * /orders:
 *   post:
 *     summary: Ajoute un produit à l'utilisateur connecté
 *     tags: [Orders]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               productName:
 *                 type: string
 *               description:
 *                 type: string
 *               price:
 *                 type: number
 *     responses:
 *       201:
 *         description: Produit ajouté avec succès
 *       400:
 *         description: Requête invalide
 *       500:
 *         description: Erreur serveur
 */

/**
 * @swagger
 * /orders:
 *   get:
 *     summary: Récupère toutes les commandes
 *     tags: [Orders]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des commandes récupérée
 */
router.get("/", authMiddleware, getAllOrders);
router.post("/", authMiddleware, createOrder);
module.exports = router;

