const express = require("express");
const router = express.Router();
const productController = require("../controllers/products.controller");



/**
 * @swagger
 * /products:
 *   post:
 *     summary: Ajouter un produit pour un utilisateur
 *     tags: [Products]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               productName:
 *                 type: string
 *               description:
 *                 type: string
 *               price:
 *                 type: number
 *               userId:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Produit ajouté avec succès
 *       400:
 *         description: Champs manquants ou incorrects
 *       401:
 *         description: Non autorisé (Token manquant ou invalide)
 */

router.post("/", productController.createProduct);

module.exports = router;
