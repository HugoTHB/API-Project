const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const dotenv = require("dotenv");
const sequelize = require("./config/database");
const User = require("./models/User"); //

// Chargement des variables d'environnement
dotenv.config();

// Vérification des variables d'environnement
if (!process.env.DB_NAME || !process.env.DB_USER || !process.env.DB_HOST) {
  console.error("Erreur : Certaines variables d'environnement sont manquantes !");
  process.exit(1);
}

// Vérification de la connexion à la base de données
sequelize
  .authenticate()
  .then(() => console.log("Connexion à MySQL réussie !"))
  .catch((err) => {
    console.error("Erreur de connexion à MySQL :", err);
    process.exit(1);
  });

// Importation des routes
const authRoutes = require("./routes/auth.routes");
const userRoutes = require("./routes/users.routes");
const orderRoutes = require("./routes/orders.routes");
const productRoutes = require("./routes/products.routes"); // Ajout des produits

// Swagger pour la documentation
const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Configuration Swagger
const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "API REST avec Node.js",
      version: "1.0.0",
      description: "Documentation de l'API avec Swagger",
    },
  },
  apis: ["./routes/*.js"], 
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Routes de l'API
app.use("/products", productRoutes);
app.use("/auth", authRoutes);
app.use("/users", userRoutes);
app.use("/orders", orderRoutes);
app.use("/products", productRoutes); 

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

sequelize.sync()
  .then(() => {
    console.log("Base de données synchronisée.");
    
    return User.findAll();
  })
  .then(users => {
    console.log("Utilisateurs en base :", users.map(user => user.toJSON()));
  })
  .catch(err => console.error("Erreur de synchronisation DB :", err));

app.use((req, res, next) => {
  res.status(404).json({ error: "Route non trouvée" });
});

// Gestion des erreurs globales
app.use((err, req, res, next) => {
  console.error("Erreur interne :", err);
  res.status(500).json({ error: "Erreur interne du serveur" });
});

// Démarrage du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
  console.log(`Documentation Swagger sur http://localhost:${PORT}/api-docs`);
});
